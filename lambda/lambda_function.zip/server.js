const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3001;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Sample function to get on-call engineers (mock data for now)
async function getOnCallEngineers(date) {
    // Replace this with actual logic to query DynamoDB or other data sources
    return {
        currentOnCall: {
            aws: { Engineer: 'John Doe', Email: 'john@example.com' },
            azure: { Engineer: 'Jane Smith', Email: 'jane@example.com' }
        },
        nextOnCall: {
            aws: { Engineer: 'Mike Adams', Email: 'mike@example.com' },
            azure: { Engineer: 'Sarah Connor', Email: 'sarah@example.com' }
        }
    };
}

// POST route to handle form submissions
app.post('/getOnCall', async (req, res) => {
    const { date } = req.body;
    try {
        const onCallInfo = await getOnCallEngineers(date);
        res.json(onCallInfo);
    } catch (error) {
        console.error("Error fetching on-call schedule:", error);
        res.status(500).send("Internal Server Error");
    }
});

// GET route to test via browser
app.get('/getOnCall', async (req, res) => {
    const date = req.query.date;
    try {
        const onCallInfo = await getOnCallEngineers(date);
        res.json(onCallInfo);
    } catch (error) {
        console.error("Error fetching on-call schedule:", error);
        res.status(500).send("Internal Server Error");
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://127.0.0.1:${port}`);
});
